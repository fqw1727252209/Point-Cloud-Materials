#include <cstdio>

int main(int argc, char* argv[]){
    printf_s("Hello, World!\n");
    getchar();
    return 0;
}